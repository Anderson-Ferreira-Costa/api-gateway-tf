terraform import aws_api_gateway_rest_api.cadastro_produto jotmmb5bdk
terraform import aws_api_gateway_deployment.cadastro_produto jotmmb5bdk/kwb2k1
terraform import aws_api_gateway_vpc_link.cadastro_produto wwz3y2
terraform import 'aws_lb.this["NLB-K8S-CADASTRO-PRODUTO"]' arn:aws:elasticloadbalancing:ca-central-1:129201766587:loadbalancer/net/NLB-K8S-CADASTRO-PRODUTO/7a13adb4436a7a40
terraform import 'aws_lb_listener.cadastro_produto[0]' arn:aws:elasticloadbalancing:ca-central-1:129201766587:listener/net/NLB-K8S-CADASTRO-PRODUTO/7a13adb4436a7a40/10126524f88126a6
terraform import 'aws_lb_listener.cadastro_produto[1]' arn:aws:elasticloadbalancing:ca-central-1:129201766587:listener/net/NLB-K8S-CADASTRO-PRODUTO/7a13adb4436a7a40/983af612726f0d69
terraform import aws_lb_target_group.cadastro_produto arn:aws:elasticloadbalancing:ca-central-1:129201766587:targetgroup/TG-NLB-K8S-CADASTRO-PRODUTO/66a516372f6224a4



terraform import aws_api_gateway_rest_api.roteador_cartao_credito xfkofgul3b
terraform import aws_api_gateway_deployment.roteador_cartao_credito xfkofgul3b/j4jrkm
terraform import aws_api_gateway_vpc_link.roteador_cartao_credito egpsjq
terraform import 'aws_lb.this["NLB-K8S-MEIOSDEPAGAMENTO"]' arn:aws:elasticloadbalancing:ca-central-1:129201766587:loadbalancer/net/NLB-K8S-MEIOSDEPAGAMENTO/21be6b38d29342b1
terraform import 'aws_lb_listener.roteador_cartao_credito[0]' arn:aws:elasticloadbalancing:ca-central-1:129201766587:listener/net/NLB-K8S-MEIOSDEPAGAMENTO/21be6b38d29342b1/8fe672298d36e817
terraform import 'aws_lb_listener.roteador_cartao_credito[1]' arn:aws:elasticloadbalancing:ca-central-1:129201766587:listener/net/NLB-K8S-MEIOSDEPAGAMENTO/21be6b38d29342b1/173930e60f0c17b3
terraform import aws_lb_target_group.roteador_cartao_credito arn:aws:elasticloadbalancing:ca-central-1:129201766587:targetgroup/TG-NLB-K8S-MEIOSDEPAGAMENTO/de1919ccf033ec08
