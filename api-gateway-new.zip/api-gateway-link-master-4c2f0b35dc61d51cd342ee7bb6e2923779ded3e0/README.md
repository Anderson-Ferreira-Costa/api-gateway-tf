<h1 align="center">Terraform API Gateway</h1>

- Forums: [HashiCorp Discuss](https://discuss.hashicorp.com/c/terraform-core)
- Documentation: https://www.terraform.io/docs/
- Tutorials: [HashiCorp's Learn Platform](https://learn.hashicorp.com/terraform)

## Introdução
Esse template tem como principal funçãoo criar um API Gateway, com Network Load Balancers e CloudFront. 

## Requisitos para rodar o template
**1** - Ter acesso a pipeline Jenkins criada para aplicar este template.

**2** - Fazer a leitura do readme.md com atenção para um melhor entendimento do código.

## Armazenamento do terraform state
É necessário que o terraform state seja armazenado em um local seguro, para que o mesmo não fique na máquina local que está sendo usada para aplicar o template. Sendo assim, deve-se fazer o apontamento do state para um Bucket S3 criado em uma conta AWS.
> Atente-se para que o bucket onde o state será armezenado esteja com o **versionamento ATIVO**.

O apontamento será feito pelo arquivo `backend.tf`. Observe no exemplo abaixo como é feito o processo:

```shell
terraform {
  backend "s3" {
    region     = var.region  
    bucket     = "terraform-state-bucket"
    key        = "usr/vpc/terraform.state"
  }
}
```
## Como utilizar o código
####  IMPORTANTE

1 - Altere as variáveis no arquivo `variables.auto.tfvars` de acordo com o necessário.

2 - Importe o arquivo swagger diretamente do painel do API Gateway da aws para garantir que esteja atualizado. Leia a documentação a seguir caso tenha dúvidas: 
- https://docs.aws.amazon.com/apigateway/latest/developerguide/api-gateway-export-api.html.

3 - Se atente bem para a variável `apigw_apply_swagger_file`. Esta variável, está por default como `false`, caso precise reconstruir o Api Gateway do zero, coloque essa variável como `true`.

4 - Se atente bem para a variável `lb_attachment_instances`. Esta variável, está por default como `false`, caso precise reconstruir o NLB do zero, coloque essa variável como `true` para que os nodes do cluster EKS sejam atachadas ao target group.

####  JENKINS
Para aplicar o código utilize o jenkins. Acesse o link abaixo e execute a pipeline.

- https://jenkinsportoprd.portoseguro.brasil/job/FrentesDigitais/job/meiosdepagamento/job/Terraform/job/terraform-dev/job/api-gateway/

<!-- BEGIN_TF_DOCS -->
## Requirements

| Name | Version |
|------|---------|
| <a name="requirement_terraform"></a> [terraform](#requirement\_terraform) | >= 0.13.1 |
| <a name="requirement_aws"></a> [aws](#requirement\_aws) | >= 3.73 |

## Providers

| Name | Version |
|------|---------|
| <a name="provider_aws"></a> [aws](#provider\_aws) | 4.48.0 |
| <a name="provider_aws.virginia"></a> [aws.virginia](#provider\_aws.virginia) | 4.48.0 |

## Resources

| Name | Type |
|------|------|
| [aws_api_gateway_deployment.this](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/api_gateway_deployment) | resource |
| [aws_api_gateway_integration.decrypt_integration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/api_gateway_integration) | resource |
| [aws_api_gateway_integration.filter_integration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/api_gateway_integration) | resource |
| [aws_api_gateway_integration.id_integration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/api_gateway_integration) | resource |
| [aws_api_gateway_integration.issue_integration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/api_gateway_integration) | resource |
| [aws_api_gateway_integration.issuev2_integration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/api_gateway_integration) | resource |
| [aws_api_gateway_integration.paid_integration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/api_gateway_integration) | resource |
| [aws_api_gateway_integration.situation_integration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/api_gateway_integration) | resource |
| [aws_api_gateway_integration_response.decrypt_integration_response](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/api_gateway_integration_response) | resource |
| [aws_api_gateway_integration_response.filter_integration_response](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/api_gateway_integration_response) | resource |
| [aws_api_gateway_integration_response.id_integration_response](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/api_gateway_integration_response) | resource |
| [aws_api_gateway_integration_response.issue_integration_response](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/api_gateway_integration_response) | resource |
| [aws_api_gateway_integration_response.issuev2_integration_response](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/api_gateway_integration_response) | resource |
| [aws_api_gateway_integration_response.paid_integration_response](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/api_gateway_integration_response) | resource |
| [aws_api_gateway_integration_response.situation_integration_response](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/api_gateway_integration_response) | resource |
| [aws_api_gateway_rest_api.this](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/api_gateway_rest_api) | resource |
| [aws_api_gateway_vpc_link.pci](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/api_gateway_vpc_link) | resource |
| [aws_api_gateway_vpc_link.pix](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/api_gateway_vpc_link) | resource |
| [aws_cloudfront_distribution.pci](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/cloudfront_distribution) | resource |
| [aws_cloudfront_distribution.pix](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/cloudfront_distribution) | resource |
| [aws_cloudfront_origin_access_identity.pci](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/cloudfront_origin_access_identity) | resource |
| [aws_cloudfront_origin_access_identity.pix](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/cloudfront_origin_access_identity) | resource |
| [aws_cloudfront_origin_request_policy.this](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/cloudfront_origin_request_policy) | resource |
| [aws_lb.this](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/lb) | resource |
| [aws_lb_listener.pci](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/lb_listener) | resource |
| [aws_lb_listener.pix](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/lb_listener) | resource |
| [aws_lb_target_group.pci](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/lb_target_group) | resource |
| [aws_lb_target_group.pix](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/lb_target_group) | resource |
| [aws_lb_target_group_attachment.pci](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/lb_target_group_attachment) | resource |
| [aws_lb_target_group_attachment.pix](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/lb_target_group_attachment) | resource |
| [aws_s3_bucket_policy.allow_access_from_cloudfront_oai_pci](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/s3_bucket_policy) | resource |
| [aws_s3_bucket_policy.allow_access_from_cloudfront_oai_pix](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/s3_bucket_policy) | resource |
| [aws_acm_certificate.amazon_issued](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/acm_certificate) | data source |
| [aws_api_gateway_resource.decrypt](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/api_gateway_resource) | data source |
| [aws_api_gateway_resource.filter](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/api_gateway_resource) | data source |
| [aws_api_gateway_resource.id](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/api_gateway_resource) | data source |
| [aws_api_gateway_resource.issue](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/api_gateway_resource) | data source |
| [aws_api_gateway_resource.paid](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/api_gateway_resource) | data source |
| [aws_api_gateway_resource.payments](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/api_gateway_resource) | data source |
| [aws_api_gateway_resource.situation](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/api_gateway_resource) | data source |
| [aws_api_gateway_resource.v2issue](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/api_gateway_resource) | data source |
| [aws_iam_policy_document.s3_policy_cloudfront_pci](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/iam_policy_document) | data source |
| [aws_iam_policy_document.s3_policy_cloudfront_pix](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/iam_policy_document) | data source |
| [aws_instances.this](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/instances) | data source |
| [aws_s3_bucket.pci](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/s3_bucket) | data source |
| [aws_s3_bucket.pix](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/s3_bucket) | data source |
| [aws_subnets.this](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/subnets) | data source |
| [aws_vpc.this](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/vpc) | data source |
| [aws_waf_web_acl.waf](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/waf_web_acl) | data source |
| [aws_wafv2_web_acl.waf](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/wafv2_web_acl) | data source |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_apigw_apply_swagger_file"></a> [apigw\_apply\_swagger\_file](#input\_apigw\_apply\_swagger\_file) | Coloque como TRUE, caso precise criar o Api Gateway do zero. Estando com valor TRUE essa variável permite que o código pegue o swagger file do repositório e aplique como uma no api. | `bool` | `false` | no |
| <a name="input_apigw_connection_type"></a> [apigw\_connection\_type](#input\_apigw\_connection\_type) | Tipo de conexão que os métodos irão realizar. | `string` | n/a | yes |
| <a name="input_apigw_endpoint_configuration"></a> [apigw\_endpoint\_configuration](#input\_apigw\_endpoint\_configuration) | Tipo do endpoint que será configurado. | `list(string)` | n/a | yes |
| <a name="input_apigw_filter_request_parameters"></a> [apigw\_filter\_request\_parameters](#input\_apigw\_filter\_request\_parameters) | Request parameters utilizados na integração do recurso filter do Api Gateway | `map` | n/a | yes |
| <a name="input_apigw_id_request_parameters"></a> [apigw\_id\_request\_parameters](#input\_apigw\_id\_request\_parameters) | Request parameters utilizados na integração do recurso id do Api Gateway | `map` | n/a | yes |
| <a name="input_apigw_name"></a> [apigw\_name](#input\_apigw\_name) | Nome do API Gateway. | `string` | n/a | yes |
| <a name="input_apigw_vpc_link_pci_name"></a> [apigw\_vpc\_link\_pci\_name](#input\_apigw\_vpc\_link\_pci\_name) | Nome do VPC LINK do PCI | `string` | n/a | yes |
| <a name="input_apigw_vpc_link_pix_name"></a> [apigw\_vpc\_link\_pix\_name](#input\_apigw\_vpc\_link\_pix\_name) | Nome do VPC LINK do PIX | `string` | n/a | yes |
| <a name="input_cloudfront_allowed_methods_complete"></a> [cloudfront\_allowed\_methods\_complete](#input\_cloudfront\_allowed\_methods\_complete) | Lista completa de métodos que podem ser utilizados nos behaviors do CloudFront. | `list(string)` | <pre>[<br>  "GET",<br>  "HEAD",<br>  "OPTIONS",<br>  "PUT",<br>  "POST",<br>  "PATCH",<br>  "DELETE"<br>]</pre> | no |
| <a name="input_cloudfront_behavior_protocol_policy"></a> [cloudfront\_behavior\_protocol\_policy](#input\_cloudfront\_behavior\_protocol\_policy) | Use esse elemento para especificar o protocolo que os usuários podem usar para acessar os arquivos na origem especificada por TargetOriginId quando uma solicitação corresponder ao padrão de caminho em PathPattern. | `list(string)` | <pre>[<br>  "allow-all",<br>  "https-only",<br>  "redirect-to-https"<br>]</pre> | no |
| <a name="input_cloudfront_default_root_object"></a> [cloudfront\_default\_root\_object](#input\_cloudfront\_default\_root\_object) | Default root objetct que deve ser inserido na distribuição do CloudFront. | `string` | `"index.html"` | no |
| <a name="input_cloudfront_origin_request_policy_name"></a> [cloudfront\_origin\_request\_policy\_name](#input\_cloudfront\_origin\_request\_policy\_name) | Nome da policy do Origin Request | `string` | n/a | yes |
| <a name="input_cloudfront_path_pattern"></a> [cloudfront\_path\_pattern](#input\_cloudfront\_path\_pattern) | O padrão (por exemplo, /api/*) que especifica a quais solicitações você deseja que esse comportamento de cache se aplique. | `string` | n/a | yes |
| <a name="input_cloudfront_pci_alias"></a> [cloudfront\_pci\_alias](#input\_cloudfront\_pci\_alias) | Alias do cloudfront destinado do PCI | `list(string)` | n/a | yes |
| <a name="input_lb_attachment_instances"></a> [lb\_attachment\_instances](#input\_lb\_attachment\_instances) | Esta variável deve receber valor TRUE caso todos os recurso precisem ser recriados do zero | `bool` | `false` | no |
| <a name="input_lb_name"></a> [lb\_name](#input\_lb\_name) | Nome dos Load Balancers que serão criados. | `list(string)` | n/a | yes |
| <a name="input_lb_port_listeners"></a> [lb\_port\_listeners](#input\_lb\_port\_listeners) | Lista de portas que devem ser inseridas nos listeners do Load Balancer. | `list(number)` | n/a | yes |
| <a name="input_lb_target_group_pci_name"></a> [lb\_target\_group\_pci\_name](#input\_lb\_target\_group\_pci\_name) | Nome do Target Group do PCI | `string` | n/a | yes |
| <a name="input_lb_target_group_pix_name"></a> [lb\_target\_group\_pix\_name](#input\_lb\_target\_group\_pix\_name) | Nome do Target Group do PIX | `string` | n/a | yes |
| <a name="input_vpc_id"></a> [vpc\_id](#input\_vpc\_id) | Esta variável tem como função receber o valor do VPC id que será consultado por um Data Resource | `string` | n/a | yes |

## Outputs

No outputs.
<!-- END_TF_DOCS -->

## Links
Para mais informações acesse os links abaixo:

- https://aws.amazon.com/pt/api-gateway/